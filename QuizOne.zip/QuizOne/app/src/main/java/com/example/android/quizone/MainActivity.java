/**
 * IMPORTANT: Make sure you are using the correct package name.
 * This example uses the package name: package com.example.android.quizone
 * If you get an error when copying this code into Android studio, update it to match the package name found
 * in the project's AndroidManifest.xml file.
 **/
package com.example.android.quizone;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This app displays a quiz one form.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the "check your answers button" is clicked.
     */
    public void checkYourAnswers(View view) {

        /**
         * set visibility of the name and outcome textViews
         */
        //TextView yourName = findViewById(R.id.y_name);
        //yourName.setVisibility(View.VISIBLE);

        // TextView outcome = findViewById(R.id.test_outcome);
        // outcome.setVisibility(View.VISIBLE);

        findViewById(R.id.text_outcome).setVisibility(View.VISIBLE);

        /**
         * EditText view, get written data from the EditText field,,
         * and store the edit data in a new String variable.
         */
        EditText yourNameField = findViewById(R.id.your_name_field);
        //String name = yourNameField.getText().toString();

        //Setting the messages to null after each press of the 'Check your answers' key.
        String message1;
        String message2;
        String message3;
        String message4;
        String message;
        //Setting score to zero after each press of the 'Check your answers' key.
        int score1 = 0;
        int score2 = 0;
        int score3 = 0;
        int score4 = 0;

        /**
         * Question 1.
         * RadioButton, get checked stat from the RadioGroup,
         * and store the checked state value in a boolean variables.
         *
         * Reading the state of the radioButtons.
         */
        RadioButton buttonRadio = findViewById(R.id.button_radio);
        RadioButton buttonTextView = findViewById(R.id.text_view_radio);
        RadioButton buttonImageView = findViewById(R.id.image_view_radio);

        // Check which radio button was checked.
        if (buttonRadio.isChecked()) {
            // Button object
            message1 = getString(R.string.q1_it_is_not_a_button_object);
            //score1 = 0;
        } else if (buttonTextView.isChecked()) {
            // TextView object
            message1 = getString(R.string.q1_it_is_not_a_textview_object);
            //score1 = 0;
        } else if (buttonImageView.isChecked()) {
            // ImageView object
            message1 = getString(R.string.q1_you_are_right);
            score1 = 1;
        } else {
            // No radio button has been selected.
            message1 = getString(R.string.q1_you_have_not_made_any_choice);
            //    score1 = 0;
        }

        /**
         * Question 2.
         * reading and comparison of characters entered
         * into the "Three Letter Acronym"  EditText field
         */
        TextView threeLetterAcronym = findViewById(R.id.three_letter_acronym);
        String acronym = threeLetterAcronym.getText().toString();

        String xml = "XML";
        if ((xml.equals(acronym))) {
            message2 = getString(R.string.q2_you_are_right);
            score2 = 1;
        } else {
            message2 = getString(R.string.q2_try_again);
            //score2 = 0;
        }

        /**
         * Question 3, Reading the state of the radioButtons.
         */
        CheckBox methodName = findViewById(R.id.method_name);
        CheckBox constructorMethod = findViewById(R.id.constructor_method);
        CheckBox factoryMethod = findViewById(R.id.factory_method);

        boolean m = true;
        boolean c = false;
        boolean f = false;

        if (methodName.isChecked()) {
            m = false;
        }
        if (constructorMethod.isChecked()) {
            c = true;
        }
        if (factoryMethod.isChecked()) {
            f = true;
        }
        if (m && c && f) {
            message3 = getString(R.string.q3_you_are_right);
            score3 = 1;
        } else {
            message3 = getString(R.string.q3_this_is_not_the_correct_answer);
            //score3 = 0;
        }

        /**
         * Question 4
         * Which checkbox is checked
         */
        CheckBox extract = findViewById(R.id.localize_extract);
        CheckBox update = findViewById(R.id.localize_update);
        CheckBox translate = findViewById(R.id.localize_translate);

        if ((extract.isChecked()) && update.isChecked() && translate.isChecked()) {
            message4 = getString(R.string.q4_you_are_right);
            score4 = 1;
        } else {
            message4 = getString(R.string.q4_this_is_not_the_full_answer);
            //score4 = 0;
        }

        /**
         * sum of points obtained for individual questions
         */
        int score = score1 + score2 + score3 + score4;

        // change int to String
        String total = Integer.toString(score);

        // change Editable to String
        String name = yourNameField.getText().toString();

        if (score < 4) {
        message = getString(R.string.summary_your_name, name);
        message += "\n" + getString(R.string.total_result, total);
        message += "\n" + getString(R.string.question_, message1);
        message += "\n" + getString(R.string.question_, message2);
        message += "\n" + getString(R.string.question_, message3);
        message += "\n" + getString(R.string.question_, message4);

        //displayName(name);
        display(message);

        /**
         * if not all the answers are correct, Toast is displayed
         */
        //if (score < 4) {
            Toast.makeText(this, getString(R.string.toast_try_again_), Toast.LENGTH_SHORT).show();
        }
        else
            {
                /**
                 * if all the answers are correct, Toast is displayed
                 */
                //if (score = 4)
                Toast.makeText(this, getString(R.string.congratulations), Toast.LENGTH_SHORT).show();

                /**
                 * Removal of the previously displayed content of the Outcome field
                 * for the case when the user moves back to the previous screen.
                 */
                message = null;
                display(message);

                /**
                 * Displays the result if all correct answers are provided.
                 */
                Intent i = new Intent( this, Main2Activity.class );
                startActivity( i );
        }
    }

    /**
     * display method
     * @param text
     * displays result of the quiz in the  Outcome TextView field defined in the activity_main.xml file.
     */
    private void display(String text) {
        TextView outcomeText = findViewById(R.id.text_outcome);
        outcomeText.setText(text);
    }
}
